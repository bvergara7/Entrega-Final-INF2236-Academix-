/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Modelos.Docente;
import Modelos.DocenteDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DocenteG implements DocenteDB {
    public String query;
    
    public ArrayList<Docente> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Docente";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Docente doc = new Docente();
               doc.setRut(rs.getString("rut"));
               doc.setNombre(rs.getString("nombre"));
               doc.setEdad(rs.getInt("edad"));
               doc.setEmail(rs.getString("email"));
               doc.setContrasena(rs.getString("contrasena"));
               doc.setEspecialidad(rs.getString("especialidad"));
               doc.setNivelEducativo(rs.getString("nivelEducativo"));
               
               ListaDocentes.add(doc);
                
            }
            
            return ListaDocentes;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
   
    
    
    
    public boolean Crear(Connection link, Docente doc){
        
        try{
            Statement s = link.createStatement();
            query = "INSERT INTO Docente(especialidad, nivelEducativo, rut, nombre, edad, email, contrasena) "
                + "VALUES('" + doc.getEspecialidad() + "','" + doc.getNivelEducativo() + "','" + doc.getRut() + "','"
                + doc.getNombre() + "'," + doc.getEdad() + ",'" + doc.getEmail() + "','" + doc.getContrasena() + "')";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    public Docente Buscar(Connection link, String rut){
        Docente doc = new Docente();
        try {
            
            Statement s = link.createStatement();
            query="select * from Docente where rut='"+rut+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next()){
                
               doc.setRut(rs.getString("rut"));
               doc.setNombre(rs.getString("nombre"));
               doc.setEdad(rs.getInt("edad"));
               doc.setEmail(rs.getString("email"));
               doc.setContrasena(rs.getString("contrasena"));
               
               doc.setEspecialidad(rs.getString("especialidad"));
               doc.setNivelEducativo(rs.getString("nivelEducativo"));
               

            }
            return doc;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    @Override
   
    
    public boolean Actualizar(Connection link, Docente doc){
        try{
            Statement s = link.createStatement();
           
            query="UPDATE Docente set especialidad='"+doc.getEspecialidad()+"',grado='"+doc.getNivelEducativo()+
                    "',rut='"+doc.getRut()+"',nombre='"+doc.getNombre()+"',edad="+doc.getEdad()+
                    ",email='"+doc.getEmail()+"',contrasena='"+doc.getContrasena()+                   
                    "' WHERE rut='"+doc.getRut()+"'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
         
    }

    @Override
    public boolean Eliminar(Connection link, String rut) {
           try {
            //aqui hay que buscar si se encuentra 
            
            Statement s = link.createStatement();
            query="delete FROM Docente where rut='"+rut+"'";
            ResultSet rs=s.executeQuery(query);
            
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    
}
