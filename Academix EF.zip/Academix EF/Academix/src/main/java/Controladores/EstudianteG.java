/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Modelos.Estudiante;
import Modelos.EstudianteDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */

public class EstudianteG implements EstudianteDB {
    public String query;
    
    @Override
    public ArrayList<Estudiante> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Estudiante";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Estudiante est= new Estudiante();
               est.setRut(rs.getString("rut"));
               est.setNombre(rs.getString("nombre"));
               est.setEdad(rs.getInt("edad"));
               est.setEmail(rs.getString("email"));
               est.setContrasena(rs.getString("contrasena"));
               
               est.setApodo(rs.getString("apodo"));
               est.setAreaEstudio(rs.getString("areaEstudio"));
               est.setGrado(rs.getString("grado"));
               
               ListaEstudiantes.add(est);
                
            }
            
            return ListaEstudiantes;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    
   
    
    
    
    @Override
    public boolean Crear(Connection link, Estudiante est)
    {   
        
        try
        {
            query = "INSERT INTO Estudiante(apodo, areaEstudio, grado, rut, nombre, edad, email, contrasena) "
                     + "VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement q = link.prepareStatement(query);
            q.setString(1, est.getApodo());
            q.setString(2, est.getAreaEstudio());
            q.setString(3, est.getGrado());
            q.setString(4, est.getRut());
            q.setString(5, est.getNombre());
            q.setInt(6,est.getEdad());
            q.setString(7, est.getEmail());
            q.setString(8, est.getContrasena());
            q.executeUpdate();
            return true;
            
       
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
        
      

    
    @Override
    public Estudiante Buscar(Connection link, String rut){
        Estudiante est=new Estudiante();
        
        try {
            Statement s = link.createStatement();
            query="select * from Estudiante where rut='"+rut+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next()){
                
               est.setRut(rs.getString("rut"));
               est.setNombre(rs.getString("nombre"));
               est.setEdad(rs.getInt("edad"));
               est.setEmail(rs.getString("email"));
               est.setContrasena(rs.getString("contrasena"));
               
               est.setApodo(rs.getString("apodo"));
               est.setAreaEstudio(rs.getString("areaEstudio"));
               est.setGrado(rs.getString("grado"));
               

            }
            return est;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    @Override
   
    
    public boolean Actualizar(Connection link, Estudiante est)
    {
        try{
            Statement s = link.createStatement();
            
            query = "UPDATE Estudiante SET apodo='" + est.getApodo() + "', areaEstudio='" + est.getAreaEstudio() +
                "', grado='" + est.getGrado() + "', nombre='" + est.getNombre() + "', edad=" + est.getEdad() +
                ", email='" + est.getEmail() + "', contrasena='" + est.getContrasena() +
                "' WHERE rut='" + est.getRut() + "'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
       
    }

        
 


    @Override
   public boolean Eliminar(Connection link, String rut) 
   {
    try {
        // Aquí hay que buscar si se encuentra 
        Statement s = link.createStatement();
        String query = "DELETE FROM Estudiante WHERE rut='" + rut + "'";
        int verFilas = s.executeUpdate(query);

        // Verificar si se eliminó al menos una fila
        if (verFilas > 0) {
            return true;
        } else {
            return false; 
        }
    } catch (SQLException ex) {
        Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        return false; 
    }
  }  
}
