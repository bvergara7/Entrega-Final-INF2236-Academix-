/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Modelos.Reunion;
import Modelos.ReunionDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */

public class ReunionG implements ReunionDB {
    public String query;
    
    public ArrayList<Reunion> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Reunion";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Reunion reunion=new Reunion();
               reunion.setMensaje(rs.getString("mensaje"));
               reunion.setLinkReunion(rs.getString("linkReunion"));
               
              
               reunion.setFechaReunion(rs.getString("fechaReunion"));
               reunion.setEstado(rs.getString("estado"));
               reunion.setIdReunion(rs.getString("idReunion"));
               reunion.setSiglaCurso(rs.getString("siglaCurso"));
               
               ListaReunion.add(reunion);
                
            }
            
            return ListaReunion;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
   
    
    
    
    public boolean Crear(Connection link, Reunion reunion){
        
        try{
            Statement s = link.createStatement();
            query="INSERT INTO  Reunion( mensaje, linkReunion, fechaReunion, estado, idReunion, siglaCurso) VALUES('"+reunion.getLinkReunion()+"','"+reunion.getFechaReunion()+"','"+reunion.getEstado()+"','"+reunion.getIdReunion()+"','"+reunion.getSiglaCurso()+"')";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    public Reunion Buscar(Connection link, String idReunion){
        Reunion reunion=new Reunion();
        try {
            Statement s = link.createStatement();
            query="select * from Reunion where idReunion='"+idReunion+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next()){
                

               reunion.setMensaje(rs.getString("mensaje"));
               reunion.setLinkReunion(rs.getString("linkReunion"));
               reunion.setFechaReunion(rs.getString("fechaReunion"));
               reunion.setEstado(rs.getString("estado"));
               reunion.setIdReunion(rs.getString("idReunion"));
               reunion.setIdReunion(rs.getString("siglaCurso"));

            }
            return reunion;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    @Override
   
    
    public boolean Actualizar(Connection link, Reunion reunion){
        try{
            Statement s = link.createStatement();
            
            
            query="UPDATE Reunion set linkReunion='"+reunion.getLinkReunion()+"',fechaReunion='"+reunion.getFechaReunion()+"',estado='"+reunion.getEstado()+"',idReunion='"+reunion.getIdReunion()+"',siglaCurso='"+reunion.getSiglaCurso()+"' WHERE idReunion='"+reunion.getIdReunion()+"'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
       
    }

    @Override
    public boolean Eliminar(Connection link, String idReunion) {
           try {
            //aqui hay que buscar si se encuentra 
            
            Statement s = link.createStatement();
            query="delete * Reunion where idReunion='"+idReunion+"'";
            ResultSet rs=s.executeQuery(query);
            
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    
}

