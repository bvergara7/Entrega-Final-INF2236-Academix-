/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;


import Modelos.PerteneceDB;
import static Modelos.PerteneceDB.ListaPertenece;
import Modelos.Pertenece;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bverg
 */
public class PerteneceG implements PerteneceDB
{
    public String query;
    
    public ArrayList<Pertenece> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Pertenece";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Pertenece p = new Pertenece();
               p.setRutEstudiante(rs.getString("rut"));
               p.setSiglaCurso(rs.getString("sigla"));
            
               ListaPertenece.add(p);
                
            }
            
            return ListaPertenece;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
   
    
    
    
    public boolean Crear(Connection link, Pertenece p){
        
        try{
            Statement s = link.createStatement();
            query = "INSERT INTO Pertenece(rut, sigla) VALUES('" + p.getRutEstudiante() + "','" + p.getSiglaCurso() + "')";
            
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    @Override
    public Pertenece Buscar(Connection link, String sigla)
    {
        Pertenece p = new Pertenece();
        try {
            Statement s = link.createStatement();
            query="select * from Pertenece where sigla='"+sigla+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next())
            {
                
               p.setSiglaCurso(rs.getString("sigla"));
               p.setRutEstudiante(rs.getString("rut"));
              
            }
            return p;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean Actualizar(Connection link, Pertenece p){
        try{
            Statement s = link.createStatement();
            
            
            query = "UPDATE Pertenece SET rut='" + p.getRutEstudiante() + "', sigla='" + p.getSiglaCurso() + "' WHERE sigla='" + p.getSiglaCurso() + "'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
       
    }

    public boolean Eliminar(Connection link, String sigla) 
   {
    try {
        // Aquí hay que buscar si se encuentra 
        Statement s = link.createStatement();
        String query = "DELETE FROM Pertenece WHERE sigla='" + sigla + "'";
        int verFilas = s.executeUpdate(query);

        // Verificar si se eliminó al menos una fila
        if (verFilas > 0) {
            return true;
        } else {
            return false; 
        }
    } catch (SQLException ex) {
        Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        return false; 
    }
  }  
}