/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import Modelos.MaterialDB;
import Modelos.Material;
import java.util.ArrayList;
/**
 *
 * @author kevincio
 */
public class MaterialG implements MaterialDB 
{
    public String query;

    public MaterialG() 
    {
        
    }
    
    
    
    
    public ArrayList<Material> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Material";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Material material = new Material();
               material.setLink(rs.getString("link"));
               material.setFecha(rs.getString("fecha"));
               material.setTitulo(rs.getString("titulo"));
               material.setIdMaterial(rs.getString("idMaterial"));
               material.setSiglaCurso(rs.getString("siglaCurso"));
               
               ListaMaterial.add(material);
                
            }
            
            return ListaMaterial;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    

    
    
    public boolean Crear(Connection link, Material material){
        
        try{
            Statement s = link.createStatement();
            query="INSERT INTO Material(link,fecha,titulo,idMaterial,siglaCurso)VALUES('"+material.getLink()+"','"+material.getFecha()+"','"+material.getTitulo()+"','"+material.getIdMaterial()+"',"+material.getSiglaCurso()+"')";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    public Material Buscar(Connection link, String idMaterial){
        Material material = new Material();
        try {
            Statement s = link.createStatement();
            query="select * from Material where idMaterial='"+idMaterial+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next()){
               material.setLink(rs.getString("link"));
               material.setFecha(rs.getString ("fecha"));
               material.setTitulo(rs.getString("titulo"));
               material.setIdMaterial(rs.getString("idMaterial"));
               material.setSiglaCurso(rs.getString("siglaCurso"));
                
            }
            return material;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    @Override
   
    
    public boolean Actualizar(Connection link, Material material){
        try{
            Statement s = link.createStatement();
            query="UPDATE Material set link='"+material.getLink()+"',apellidos='"+material.getFecha()+"',fechaNacimiento='"+material.getTitulo()+"',region='"+material.getIdMaterial()+"',siglaCurso='"+material.getSiglaCurso()+"'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
       
    }

    @Override
    public boolean Eliminar(Connection link, String idMaterial) {
           try {
            //aqui hay que buscar si se encuentra 
            
            Statement s = link.createStatement();
            query="delete FROM Material where idMaterial='"+idMaterial+"'";
            ResultSet rs=s.executeQuery(query);
            
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
}
