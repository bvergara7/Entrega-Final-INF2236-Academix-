/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Modelos.Curso;
import Modelos.CursoDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bverg
 */
public class CursoG implements CursoDB
{
    public String query;
    
    public ArrayList<Curso> Leer(Connection link){

        try{
            Statement s = link.createStatement();
            query="select * from Curso";
            ResultSet rs=s.executeQuery(query);
            while (rs.next()){
               Curso cs = new Curso();
               cs.setSigla(rs.getString("sigla"));
               cs.setArea(rs.getString("Area"));
               cs.setRut(rs.getString("rut"));
            
               
               ListaCursos.add(cs);
                
            }
            
            return ListaCursos;
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
   
    
    
    
    public boolean Crear(Connection link, Curso cs){
        
        try{
            Statement s = link.createStatement();
            query = "INSERT INTO Curso(sigla, area, rut) VALUES('" + cs.getSigla() + "','" + cs.getArea() + "','" + cs.getRut() + "')";
            
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    public Curso Buscar(Connection link, String sigla)
    {
        Curso cs = new Curso();
        try {
            Statement s = link.createStatement();
            query="select * from Curso where sigla='"+sigla+"'";
            ResultSet rs=s.executeQuery(query);
            
                   
   
            while (rs.next())
            {
                
               cs.setSigla(rs.getString("sigla"));
               cs.setArea(rs.getString("area"));
               cs.setRut(rs.getString("rut"));
               
       
               

            }
            return cs;
  
            
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean Actualizar(Connection link, Curso cs){
        try{
            Statement s = link.createStatement();
            
            
            query = "UPDATE Curso SET area='" + cs.getArea() + "', rut='" + cs.getRut() + "' WHERE sigla='" + cs.getSigla() + "'";
            s.executeUpdate(query);
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
       
    }

    public boolean Eliminar(Connection link, String sigla) {
           try {
            //aqui hay que buscar si se encuentra 
            
            Statement s = link.createStatement();
            query="delete FROM Curso where sigla='"+sigla+"'";
            ResultSet rs=s.executeQuery(query);
            
            return true;
            
        }catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    
    
    
}
