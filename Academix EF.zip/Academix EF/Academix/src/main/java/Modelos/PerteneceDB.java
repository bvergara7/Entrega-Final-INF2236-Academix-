package Modelos;

import java.sql.Connection;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author bverg
 */
public interface PerteneceDB 
{
    ArrayList<Pertenece>ListaPertenece=new ArrayList<Pertenece>();
    public boolean Crear(Connection link, Pertenece p);
    public boolean Actualizar(Connection link, Pertenece p);
    public boolean Eliminar(Connection link, String sigla);
    public ArrayList<Pertenece> Leer(Connection link);
    public Pertenece Buscar(Connection link, String sigla);
    
    
}
