/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelos;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author bverg
 */
public interface CursoDB 
{
    ArrayList<Curso>ListaCursos=new ArrayList<Curso>();
    public boolean Crear(Connection link, Curso cs);
    public boolean Actualizar(Connection link, Curso cs);
    public boolean Eliminar(Connection link, String sigla);
    public ArrayList<Curso> Leer(Connection link);
    public Curso Buscar(Connection link, String sigla);
    
    
}
