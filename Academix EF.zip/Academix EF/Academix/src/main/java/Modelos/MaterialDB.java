/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelos;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author lukaj
 */
public interface MaterialDB {
    ArrayList<Material>ListaMaterial=new ArrayList<Material>();
    public boolean Crear(Connection link, Material material);
    public boolean Actualizar(Connection link, Material material);
    public boolean Eliminar(Connection link, String idMaterial);
    public ArrayList<Material> Leer(Connection link);
    public Material Buscar(Connection link, String idMaterial);
}
