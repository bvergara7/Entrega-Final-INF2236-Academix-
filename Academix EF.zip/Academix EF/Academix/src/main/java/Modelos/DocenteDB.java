/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelos;

//import com.mycompany.main.Docente;
import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author lenovo
 */
public interface DocenteDB {
    ArrayList<Docente>ListaDocentes=new ArrayList<Docente>();
    public boolean Crear(Connection link, Docente est);
    public boolean Actualizar(Connection link, Docente est);
    public boolean Eliminar(Connection link, String rut);
    public ArrayList<Docente> Leer(Connection link);
    public Docente Buscar(Connection link, String rut);
}