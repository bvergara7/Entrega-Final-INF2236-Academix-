/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bverg
 */
public class Pertenece 
{
   private String rutEstudiante;
   private String siglaCurso;

    public Pertenece(String rutEstudiante, String siglaCurso) {
        this.rutEstudiante = rutEstudiante;
        this.siglaCurso = siglaCurso;
    }

    public Pertenece() {
    }

    public String getRutEstudiante() {
        return rutEstudiante;
    }

    public void setRutEstudiante(String rutEstudiante) {
        this.rutEstudiante = rutEstudiante;
    }

    public String getSiglaCurso() {
        return siglaCurso;
    }

    public void setSiglaCurso(String siglaCurso) {
        this.siglaCurso = siglaCurso;
    }
   
    public void mostrar()
    {
        System.out.println("Rut del Estudiante" + getRutEstudiante());
        System.out.println("Sigla Curso" + getSiglaCurso());
        
    }

}