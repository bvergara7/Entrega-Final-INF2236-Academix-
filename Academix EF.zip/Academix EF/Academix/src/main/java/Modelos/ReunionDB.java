/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelos;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author lenovo
 */
public interface ReunionDB {
    ArrayList<Reunion>ListaReunion=new ArrayList<Reunion>();
    public boolean Crear(Connection link, Reunion reunion);
    public boolean Actualizar(Connection link, Reunion reunion);
    public boolean Eliminar(Connection link, String idReunion);
    public ArrayList<Reunion> Leer(Connection link);
    public Reunion Buscar(Connection link, String idReunion);
}
