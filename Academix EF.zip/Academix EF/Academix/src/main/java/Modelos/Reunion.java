/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;


public class Reunion 
{
    private String mensaje;
    private String linkReunion;
    private String fechaReunion;
    private String estado;
    private String idReunion;
    private String siglaCurso;
    
    
  
    public Reunion(String mensaje, String linkReunion, String fechaReunion, String estado, String idReunion, String siglaCurso) 
    {
        this.mensaje = mensaje;
        this.linkReunion = linkReunion;
        this.fechaReunion = fechaReunion;
        this.estado = estado;
        this.idReunion = idReunion;
        this.siglaCurso = siglaCurso;
    }
    
    public Reunion()
    {
    }    

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getLinkReunion() {
        return linkReunion;
    }

    public void setLinkReunion(String linkReunion) {
        this.linkReunion = linkReunion;
    }

    public String getFechaReunion() {
        return fechaReunion;
    }

    public void setFechaReunion(String fechaReunion) {
        this.fechaReunion = fechaReunion;
    }

    public String getIdReunion() {
        return idReunion;
    }

    public void setIdReunion(String idReunion) {
        this.idReunion = idReunion;
    }

    public String getSiglaCurso() {
        return siglaCurso;
    }

    public void setSiglaCurso(String siglaCurso) {
        this.siglaCurso = siglaCurso;
    }
    
    
    
       
    public void mostrar()
    {
        System.out.println("Mensaje: " + getMensaje());
        System.out.println("Link Reunion:  " +  getLinkReunion());
        System.out.println("Fecha de la Reunion:  " + getFechaReunion());
        System.out.println("Estado de la Reunion: " + getEstado());
        System.out.println("Id Reunion: " + getIdReunion());
        System.out.println("Curso: " + getSiglaCurso());
    }
}