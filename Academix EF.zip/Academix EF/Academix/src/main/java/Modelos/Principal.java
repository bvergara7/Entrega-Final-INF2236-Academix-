/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import Controladores.Conexion;
import Controladores.CursoG;
import Controladores.DocenteG;
import Controladores.EstudianteG;
import Controladores.MaterialG;
import Controladores.ReunionG;
import static Modelos.EstudianteDB.ListaEstudiantes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author bverg
 */
public class Principal 
{
    
    public static void main(String args[]) throws ParseException
    {
        
        //Conexion a BD
        Conexion conn = new Conexion();
        Connection link = conn.Conectar();
        
        
        /*
        
        //Estudiante
        EstudianteG est = new EstudianteG();
        
        Estudiante estReal = new Estudiante("Benja","Informatica","2","123555","Benjamin",20,"bverg@gmail.com","benjamin12345");    
        
        est.Crear(link, estReal);
        
        Estudiante estReal2 = new Estudiante("Kevin","Informatica","2","263556","Benjamin",20,"bverg@gmail.com","benjamin12345");    
        
        est.Crear(link, estReal2);
        
        est.Leer(link);
        
        // caso no esta
        
        Estudiante bus = est.Buscar(link, "263556");
        if(bus.getRut()!= null) System.out.println("yeiii");
        else System.out.println("putxha :(");
      
        for(int i = 0; i < ListaEstudiantes.size(); i++){
            System.out.println(ListaEstudiantes.get(i).getRut());
        }
       
        /*
     
       

                  
        //Docente
        DocenteG doc = new DocenteG();
        Docente docReal = new Docente("Matematicas", "Profesional","274223", "Bob", 45, "bob76@gmail.com", "hicistelocorrectobob");
        
        doc.Leer(link);
        //doc.Crear(link, docReal);
        
        docReal.mostrar();
        
        docReal.introducirDatosActualizados();
        
        boolean actualizar = est.Actualizar(link, estReal);
        
        if(actualizar)
        {
            System.out.println("Docente Actualizado");
      
            estReal.mostrar();
            
       } else {
        System.out.println("Error: No se pudo actualizar el Docente");
    
       } 
        */
        
        
        
        //Curso
        CursoG cs = new CursoG();
        Curso csIns = new Curso("INF2236", "Informatica","200");
        
        
        cs.Crear(link, csIns);
        Curso csIns2 = new Curso("INF2236", "Informatica","2020");
        
        
        cs.Crear(link, csIns2);
    
        cs.Leer(link);
        
        for (Curso curs : cs.Leer(link))
        {
            
            curs.mostrar();
            System.out.println("\n");
            
        }
        
        
        
        
        //Material
       
        conn.CerrarConexion();
    }
}

