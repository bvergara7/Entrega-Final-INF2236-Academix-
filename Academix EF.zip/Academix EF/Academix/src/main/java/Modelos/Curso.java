/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

//import com.mycompany.main.Docente;

/**
 *
 * @author bverg
 */
public class Curso 
{
    private String sigla;
    private String area; 
    private String rut;

    public Curso(String sigla, String area, String rut) 
    {

        
        this.sigla = sigla;
        this.area = area;
        this.rut = rut;
        
    }
    public Curso()
    {
        
    }    

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getRut() 
     {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }
    
    
    public void mostrar()
    {
        System.out.println("Sigla: " + getSigla());
        System.out.println("Area" + getArea());
        System.out.println("Rut" + getRut());
    }       

}