/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelos;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author lenovo
 */
public interface EstudianteDB {
    ArrayList<Estudiante>ListaEstudiantes=new ArrayList<Estudiante>();
    public boolean Crear(Connection link, Estudiante est);
    public boolean Actualizar(Connection link, Estudiante est);
    public boolean Eliminar(Connection link, String rut);
    public ArrayList<Estudiante> Leer(Connection link);
    public Estudiante Buscar(Connection link, String rut);
}
