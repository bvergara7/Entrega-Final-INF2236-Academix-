package Modelos;


public class Material 
{
    private String link;
    private String fecha;
    private String titulo;
    private String idMaterial;
    private String siglaCurso;
    

    public Material(String link, String fecha, String titulo, String idMaterial, String siglaCurso) 
    {
        this.link = link;
        this.fecha = fecha;
        this.titulo = titulo;
        this.idMaterial = idMaterial;
        this.siglaCurso = siglaCurso;
    }
    
    public Material()
    {
        
    }    
    

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(String idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getSiglaCurso() {
        return siglaCurso;
    }

    public void setSiglaCurso(String siglaCurso) {
        this.siglaCurso = siglaCurso;
    }
    
    
    
    
     public void mostrar()
    {
        System.out.println("Link: " + getLink());
        System.out.println("Fecha " +  getFecha());
        System.out.println("titulo " + getTitulo());
        System.out.println("Apodo: " + getIdMaterial());
        System.out.println("Sigla del Curso" + getSiglaCurso());
        
    }

}