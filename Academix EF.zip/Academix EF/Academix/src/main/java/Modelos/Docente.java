/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;
/**
 *
 * @author lukaj
 */
public class Docente extends Persona
{
    private String especialidad;
    private String nivelEducativo;

            
            
    public Docente(String especialidad, String nivelEducativo, String rut, String nombre, int edad, String email, String contrasena) {
        super(rut, nombre, edad, email, contrasena);
        this.especialidad = especialidad;
        this.nivelEducativo = nivelEducativo;
    }
    
    public Docente(){
        
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getNivelEducativo() {
        return nivelEducativo;
    }

    public void setNivelEducativo(String nivelEducativo) {
        this.nivelEducativo = nivelEducativo;
    }
    
    public void introducirDatosActualizados() 
    {
        
       
        setEspecialidad("Lenguaje");
        setNivelEducativo("Doctorado");
        setNombre("Phil");
        setEmail("phil224@gmail.com");
        setRut("11372371");
        setContrasena("122345");
        setEdad(52);

    }    
    
    public void mostrar()
    {
        System.out.println("Nombre Completo: " + getNombre());
        System.out.println("Edad del usuario: " +  getEdad());
        System.out.println("Email del usuario: " + getEmail());
        System.out.println("Contraseña: " + getContrasena());
        System.out.println("Rut:" + getRut());
        System.out.println("Especialidad" + getEspecialidad());
        System.out.println("Nivel Educativo" + getNivelEducativo());
    }    
  
    
    

}