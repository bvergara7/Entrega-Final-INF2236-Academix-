/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.util.ArrayList;


/**
 *
 * @author lenovo
 */

public class Estudiante extends Persona 
{
   
    private String apodo; 
    private String areaEstudio;
    private String grado;

    public Estudiante(String apodo, String areaEstudio, String grado,String rut, String nombre, int edad, String email, String contrasena) {
        super(rut, nombre, edad, email, contrasena);
        this.apodo = apodo;
        this.areaEstudio = areaEstudio;
        this.grado = grado;
    }

    public Estudiante() {

    }

    public String getApodo() {
        return apodo;
    }

    public void setApodo(String apodo) {
        this.apodo = apodo;
    }

    public String getAreaEstudio() {
        return areaEstudio;
    }

    public void setAreaEstudio(String areaEstudio) {
        this.areaEstudio = areaEstudio;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }
    
    
    
    public void introducirDatosActualizados() 
    {
        
        setApodo("Benji");
        setAreaEstudio("Historia");
        setGrado("3");
        setNombre("Benja");
        setEmail("BVERG223@GMAIL.COM");
        setRut("11372371");
        setContrasena("BENJAMIN12381238");
        setEdad(21);

    }    
    
    
    public void mostrar()
    {
        System.out.println("Nombre Completo: " + getNombre());
        System.out.println("Edad del usuario: " +  getEdad());
        System.out.println("Email del usuario: " + getEmail());
        System.out.println("Apodo: " + getApodo());
        System.out.println("Contraseña: " + getContrasena());
        System.out.println("Rut:" + getRut());
        System.out.println("Area Estudio" + getAreaEstudio());
    }
  
}
    
   